package com.pu.nie.braille;
import android.app.admin.DeviceAdminReceiver;


/**
 * Created by user on 3/5/17.
 */

public class Darclass extends DeviceAdminReceiver{ }


