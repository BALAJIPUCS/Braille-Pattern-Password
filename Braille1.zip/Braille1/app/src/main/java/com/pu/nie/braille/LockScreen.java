package com.pu.nie.braille;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/**
 * Created by user on 3/5/17.
 */

public class LockScreen extends Activity {

    protected static final int REQUEST_ENABLE = 0;
    DevicePolicyManager devicePolicyManager;
    ComponentName adminComponent;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lock);
        registerReceiver(broadcastReceiver, new IntentFilter("insert_password"));
        
        

        Button button = (Button) findViewById(R.id.btlocker);
        button.setOnClickListener(btnListener);

    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(broadcastReceiver);
        super.onDestroy();
    }

    Button.OnClickListener btnListener = new Button.OnClickListener() {
        public void onClick(View v) {
            adminComponent = new ComponentName(LockScreen.this, Darclass.class);
            devicePolicyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);

            if (!devicePolicyManager.isAdminActive(adminComponent)) {

                Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
                startActivityForResult(intent, REQUEST_ENABLE);
            } else {
                devicePolicyManager.lockNow();
            }

        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (REQUEST_ENABLE == requestCode) {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    
    
    
    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction() == "insert_password"){
                Toast.makeText(context, "Unlock", Toast.LENGTH_SHORT).show();
                Intent intenth = new Intent(LockScreen.this, Unlock_check.class);
                startActivity(intenth);

            }
        }
    };
    
    
}
