package com.pu.nie.braille;

import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.Locale;

/**
 * Created by user on 12/4/17.
 */

public class home extends AppCompatActivity implements View.OnClickListener {

    TextToSpeech t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        registerReceiver(broadcastReceiver, new IntentFilter("insert_password"));


        Button bthelp = (Button) findViewById(R.id.bthelp);
        bthelp.setOnClickListener(this); // calling onClick() method
        Button btabout = (Button) findViewById(R.id.btabout);
        btabout.setOnClickListener(this);
        Button btreg = (Button) findViewById(R.id.btreg);
        btreg.setOnClickListener(this);
        Button btlock = (Button) findViewById(R.id.btlock);
        btlock.setOnClickListener(this);
        Button btAudio = (Button) findViewById(R.id.btAudio);
        btAudio.setOnClickListener(this);
        Button btStar = (Button) findViewById(R.id.btStar);
        btStar.setOnClickListener(this);
        t1 = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.UK);
                }
            }
        });
    }
    @Override
    protected void onDestroy() {
        unregisterReceiver(broadcastReceiver);
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.about:
                Intent intent = new Intent(this, home.class);
                startActivity(intent);
                finish();//
                return (true);
            case R.id.exit:
                finish();
                return (true);

        }
        return (super.onOptionsItemSelected(item));
    }

    @Override
    public void onClick(View v) {
        //WindowManager.LayoutParams params = this.getWindow().getAttributes();

        switch (v.getId()) {


            case R.id.bthelp:
                Intent intenth = new Intent(this, help.class);
                startActivity(intenth);
                break;

            case R.id.btabout:
                Intent intentabt = new Intent(this, abtus.class);
                startActivity(intentabt);
                break;

            case R.id.btreg:
                Intent intentreg = new Intent(this, MainActivity.class);
                startActivity(intentreg);
                break;

            case R.id.btAudio:

                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(home.this);
                if(!TextUtils.isEmpty(sharedPreferences.getString("password", null))) {

                    //you already set pass want to change?
                    t1.speak("Want to change", TextToSpeech.QUEUE_FLUSH, null);
                }
                Intent intentAudio = new Intent(this, Audio.class);
                startActivity(intentAudio);

                break;

            case R.id.btStar:
                Intent intentStar = new Intent(this, Star.class);
                startActivity(intentStar);
                break;

            case R.id.btlock:

                Intent intentLock = new Intent(this, LockScreen.class);
                startActivity(intentLock);
                break;
            //startActivity(intent);
                /*
                params.flags = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                //TODO Store original brightness value
                params.screenBrightness = 0.01f;
                this.getWindow().setAttributes(params);*/
            default:
                break;
        }

    }
    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction() == "insert_password"){
                Toast.makeText(context, "Unlock", Toast.LENGTH_SHORT).show();
                Intent intenth = new Intent(home.this, Unlock_check.class);
                startActivity(intenth);

            }
        }
    };

}
